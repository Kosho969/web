import React, { Component } from 'react';
import '../App.css'
import logo from './img/logo.png'
class Banner extends Component{

render() {
  return(
    <div className="mainCover">
    </div>

    );
  }

}

export default Banner;
