import React, { Component } from 'react';
import '../App.css'
import logo from './img/logo.png'
class Header extends Component{

render() {
  return(
    <nav className="black" >
    <div >
      <ul>
      <li><img className="myLogo" src={logo}/></li>
      
      </ul>
      <ul id="nav-mobile" className="hide-on-med-and-down">
        <li><a href="sass.html">
          <div className="primerBoton"> Lista de Exitos</div>
        </a></li>
        <li>
        <div className="center row " style={{width:' 47em'}}>
          <div className="col s12 " >
            <div className="  grey lighten-1 row " id="topbarsearch">
              <div className="input-field col s6 s12 red-text">
                <i className=" red-text material-icons prefix">search</i>
                <input type="text" placeholder="search" id="autocomplete-input" className=" autocomplete red-text"/ >
                </div>
              </div>
            </div>
          </div> 
      </li>
        <li ><a  href="badges.html">Inicia Sesión</a></li>
        <li><a className="account" href="collapsible.html">Crea tu cuenta</a></li>
        <li><a className="account" href="collapsible.html">Subir</a></li>
        <li>
          <a class="btn-floating btn-large black">
          <i class="material-icons">menu</i>
          </a>
        </li>
      </ul>
    </div>
  </nav>
    );
  }

}

export default Header;
